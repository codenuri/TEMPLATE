﻿/*
* HOME       : www.codelec.co.kr
* EMAIL      : smkang @ codenuri.co.kr
* COURSENAME : C++ Template Programming
* MODULE     : main.cpp
* Copyright (C) 2017 CODENURI Inc. All rights reserved.
*/

#include "lib.h"

int main()
{
	foo(3);
	square(3);
}