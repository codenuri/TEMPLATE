﻿/*
* HOME       : www.codelec.co.kr
* EMAIL      : smkang @ codenuri.co.kr
* COURSENAME : C++ Template Programming
* MODULE     : lib.h
* Copyright (C) 2017 CODENURI Inc. All rights reserved.
*/

void foo(int);

template<typename T>
T square(T a);